Node modules not included in repo, you will have to add it. The products.json file is to be used in mongo use "secoms319"
as the database name and create a new collection named "Product" both are case sensitive.

----------------
Setup
npm install express <- the server
npm install cors <- to make requests to an external server
npm install body-parser <- transfer body data
nodemon assignment3_backend.js <- setup nodemon
npm install MongoDB <- mongodb install
