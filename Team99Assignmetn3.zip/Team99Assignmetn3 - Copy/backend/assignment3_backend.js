var express = require("express");
var cors = require("cors");
var app = express();
var bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");

const url = "mongodb://127.0.0.1:27017";
const dbName = "secoms319";
const client = new MongoClient(url);
const db = client.db(dbName);

app.use(cors());
app.use(bodyParser.json());

const port = 8081;

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});

// Get 
app.get("/products", async (req, res) => {
    await client.connect();
    const products = await db.collection("Product").find({}).toArray();
    res.json(products);
});

// read
app.get("/products/:id", async (req, res) => {
    const productId = parseInt(req.params.id);
    await client.connect();
    const product = await db.collection("Product").findOne({ id: productId });
    if (product) {
        res.json(product);
    } else {
        res.status(404).send('Product not found');
    }
});

// Add 
app.post("/products", async (req, res) => {
    await client.connect();
    const product = req.body;
    const result = await db.collection("Product").insertOne(product);
    res.status(201).json(result.ops[0]);
});

// Update 
app.put("/products/:id", async (req, res) => {
    const productId = parseInt(req.params.id);
    await client.connect();
    const result = await db.collection("Product").updateOne({ id: productId }, { $set: req.body });
    if (result.modifiedCount === 0) {
        res.status(404).send('Product not found');
    } else {
        res.send('Product updated successfully');
    }
});

// Delete 
app.delete("/products/:id", async (req, res) => {
    const productId = parseInt(req.params.id);
    await client.connect();
    const result = await db.collection("Product").deleteOne({ id: productId });
    if (result.deletedCount === 0) {
        res.status(404).send('Product not found');
    } else {
        res.send('Product deleted successfully');
    }
});
