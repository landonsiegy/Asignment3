// Fetch all products
function fetchProducts() {
    fetch('http://localhost:8081/products')
        .then(response => response.json())
        .then(data => displayProducts(data))
        .catch(error => console.error('Error:', error));
}

// Display products in the UI
function displayProducts(products) {
    const container = document.getElementById('productsContainer');
    container.innerHTML = '';
    products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.innerHTML = `
            <div class="card">
                <img src="${product.image}" class="card-img-top" alt="${product.title}">
                <div class="card-body">
                    <h5 class="card-title">${product.title}</h5>
                    <p class="card-text">${product.description}</p>
                    <p class="card-price">Price: $${product.price}</p>
                    <button onclick="deleteProduct(${product.id})" class="btn btn-danger">Delete</button>
                    <button onclick="prepareUpdate(${product.id})" class="btn btn-info">Update</button>
                </div>
            </div>
        `;
        container.appendChild(productDiv);
    });
}

// Add a new product
function addProduct(event) {
    event.preventDefault();
    const title = document.getElementById('newTitle').value;
    const price = parseFloat(document.getElementById('newPrice').value);
    const description = document.getElementById('newDescription').value;
    const category = document.getElementById('newCategory').value;
    const image = document.getElementById('newImage').value;

    const product = { title, price, description, category, image };
    fetch('http://localhost:8081/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        fetchProducts();  // Refresh the product list
    })
    .catch(error => console.error('Error:', error));
}

// Prepare product data for update
function prepareUpdate(id) {
    // Fetch the specific product and fill the update form
    fetch(`http://localhost:8081/products/${id}`)
    .then(response => response.json())
    .then(product => {
        document.getElementById('updateId').value = product.id;
        document.getElementById('updatePrice').value = product.price;
    })
    .catch(error => console.error('Error:', error));
}

// Update a product
function updateProduct(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById('updateId').value);
    const price = parseFloat(document.getElementById('updatePrice').value);

    fetch(`http://localhost:8081/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ price })
    })
    .then(response => {
        if (response.ok) return response.json();
        else throw new Error('Failed to update product');
    })
    .then(data => {
        console.log('Product updated', data);
        fetchProducts();  // Refresh the product list
    })
    .catch(error => console.error('Error:', error));
}

// Delete a product
function deleteProduct(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById('deleteId').value);

    fetch(`http://localhost:8081/products/${id}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            console.log('Product deleted');
            fetchProducts();  // Refresh the product list
        } else {
            throw new Error('Failed to delete product');
        }
    })
    .catch(error => console.error('Error:', error));
}

window.addEventListener('load', fetchProducts);
